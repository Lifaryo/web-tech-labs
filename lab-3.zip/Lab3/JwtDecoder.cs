﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.IdentityModel.Tokens;

public class JwtDecoder
{
    public static JsonDocument DecodeJwtPayload(string jwt)
    {
        if (string.IsNullOrEmpty(jwt))
            throw new ArgumentException("JWT token is null or empty");

        string[] parts = jwt.Split('.');
        if (parts.Length != 3)
            throw new ArgumentException("Invalid JWT token format");

        string payload = parts[1];
        string json = Base64UrlDecode(payload);
        return JsonDocument.Parse(json);
    }

    public static bool ValidateJwt(string jwt, string jwksJson)
    {
        if (string.IsNullOrWhiteSpace(jwt))
            throw new ArgumentException("JWT token is null or empty", nameof(jwt));
        if (string.IsNullOrWhiteSpace(jwksJson))
            throw new ArgumentException("JWKS JSON is null or empty", nameof(jwksJson));

        using JsonDocument jwksDoc = JsonDocument.Parse(jwksJson);
        var keys = jwksDoc.RootElement.GetProperty("keys");

        var handler = new JwtSecurityTokenHandler();
        var jwtToken = handler.ReadJwtToken(jwt);
        string kid = jwtToken.Header.Kid;

        var keyElement = keys.EnumerateArray()
            .FirstOrDefault(k => k.TryGetProperty("kid", out var kKid) && kKid.GetString() == kid);

        if (keyElement.ValueKind == JsonValueKind.Undefined)
        {
            keyElement = keys[0];
        }

        // Extract modulus (n) and exponent (e)
        string n = keyElement.GetProperty("n").GetString();
        string e = keyElement.GetProperty("e").GetString();

        RSA rsa = CreateRsaProviderFromParameters(n, e);

        var validationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            RequireSignedTokens = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new RsaSecurityKey(rsa)
        };

        try
        {
            handler.ValidateToken(jwt, validationParameters, out SecurityToken validatedToken);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static string Base64UrlDecode(string input)
    {
        string output = input.Replace('-', '+').Replace('_', '/');
        switch (output.Length % 4)
        {
            case 2: output += "=="; break;
            case 3: output += "="; break;
        }
        byte[] buffer = Convert.FromBase64String(output);
        return Encoding.UTF8.GetString(buffer);
    }

    private static byte[] Base64UrlDecodeBytes(string input)
    {
        string output = input.Replace('-', '+').Replace('_', '/');
        switch (output.Length % 4)
        {
            case 2: output += "=="; break;
            case 3: output += "="; break;
        }
        return Convert.FromBase64String(output);
    }

    private static RSA CreateRsaProviderFromParameters(string n, string e)
    {
        var rsa = RSA.Create();
        rsa.ImportParameters(new RSAParameters
        {
            Modulus = Base64UrlDecodeBytes(n),
            Exponent = Base64UrlDecodeBytes(e)
        });
        return rsa;
    }
}
