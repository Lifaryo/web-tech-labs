﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Net.Http.Headers;

[ApiController]
[Route("user")]
public class UserDataController : ControllerBase
{
    private readonly OAuthOptions _oauthOptions;

    public UserDataController(IOptions<OAuthOptions> options)
    {
        _oauthOptions = options.Value;
    }

    [HttpGet("data")]
    public async Task<IActionResult> GetUserData()
    {
        if (!Request.Cookies.TryGetValue("access_token", out var accessToken) || string.IsNullOrEmpty(accessToken))
        {
            return Unauthorized(new { error = "Access token missing" });
        }

        try
        {
            var payloadJson = JwtDecoder.DecodeJwtPayload(accessToken);

            using var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(_oauthOptions.JwtVerifyEndpoint);
            var jwks = await response.Content.ReadAsStringAsync();

            if (!JwtDecoder.ValidateJwt(accessToken, jwks))
            {
                Console.WriteLine("Invalid or expired access token according to Casdoor");
                return Unauthorized(new { error = "Invalid or expired access token" });
            }

            return Ok(payloadJson.RootElement);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error decoding JWT or validating token: " + ex.Message);
            return Unauthorized(new { error = "Invalid access token" });
        }
    }
}
