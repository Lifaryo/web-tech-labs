using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

var cert = new X509Certificate2("certs/devcert.pfx", "devpass");

builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenLocalhost(5001, listenOptions =>
        listenOptions.UseHttps(cert));
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/auth/login";
        options.AccessDeniedPath = "/auth/login";
    });
builder.Services.AddAuthorization();

builder.Services.AddSingleton<BinanceStreamManager>();
builder.Services.AddSingleton<CryptoWebSocketHandler>();
builder.Services.AddControllers();

builder.Services.Configure<OAuthOptions>(builder.Configuration.GetSection("OAuth"));

var app = builder.Build();

app.UseRouting();

app.UseWebSockets();
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapFallbackToFile("index.html");

app.Run();
