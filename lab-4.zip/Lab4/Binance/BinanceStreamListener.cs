﻿using System.Net.WebSockets;
using System.Text;
using System.Threading.Channels;

public class BinanceStreamListener
{
    private readonly string _symbol;
    private readonly Channel<string> _channel;
    private readonly CancellationToken _token;

    public BinanceStreamListener(string symbol, Channel<string> channel, CancellationToken token)
    {
        _symbol = symbol;
        _channel = channel;
        _token = token;
    }

    public async Task StartAsync()
    {
        var url = new Uri($"wss://stream.binance.com:9443/ws/{_symbol}@ticker");
        using var ws = new ClientWebSocket();

        try
        {
            await ws.ConnectAsync(url, _token);
            Console.WriteLine($"Connected to Binance stream for {_symbol}");

            var buffer = new byte[8192];
            while (!_token.IsCancellationRequested && ws.State == WebSocketState.Open)
            {
                var result = await ws.ReceiveAsync(buffer, _token);
                if (result.MessageType == WebSocketMessageType.Close)
                    break;

                var json = Encoding.UTF8.GetString(buffer, 0, result.Count);
                await _channel.Writer.WriteAsync(json, _token);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error in Binance stream for {_symbol}: {ex.Message}");
        }
        finally
        {
            _channel.Writer.Complete();
        }
    }
}