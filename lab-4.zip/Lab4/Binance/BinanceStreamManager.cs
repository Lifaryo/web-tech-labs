﻿using System.Collections.Concurrent;
using System.Threading.Channels;

public class BinanceStreamManager
{
    private readonly List<string> _defaultSymbols = new() { "btcusdt", "ethusdt", "solusdt", "dogeusdt" };
    private readonly ConcurrentDictionary<string, Channel<string>> _tracked = new();
    private readonly CancellationTokenSource _cts = new();

    public BinanceStreamManager()
    {
        foreach (var sym in _defaultSymbols)
        {
            var ch = Channel.CreateUnbounded<string>();
            _tracked[sym] = ch;
            var listener = new BinanceStreamListener(sym, ch, _cts.Token);
            _ = listener.StartAsync();
        }
    }

    public IReadOnlyDictionary<string, Channel<string>> GetTrackedStreams() => _tracked;

    public void CancelAll() => _cts.Cancel();
}