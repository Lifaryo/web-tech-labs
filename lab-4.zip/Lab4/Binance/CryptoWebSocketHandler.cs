﻿using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;

public class CryptoWebSocketHandler
{
    private readonly BinanceStreamManager _streamManager;

    public CryptoWebSocketHandler(BinanceStreamManager streamManager)
    {
        _streamManager = streamManager;
    }

    public async Task HandleSocketAsync(WebSocket socket)
    {
        var streams = _streamManager.GetTrackedStreams();
        var latest = new ConcurrentDictionary<string, string>();

        var cts = new CancellationTokenSource();

        foreach (var kvp in streams)
        {
            var symbol = kvp.Key;
            var channel = kvp.Value;

            _ = Task.Run(async () =>
            {
                try
                {
                    await foreach (var msg in channel.Reader.ReadAllAsync(cts.Token))
                    {
                        latest[symbol] = msg;
                    }
                }
                catch (OperationCanceledException)
                {

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error reading from channel for {symbol}: {ex.Message}");
                }
            });
        }

        var buffer = new byte[1024];
        var sendInterval = TimeSpan.FromSeconds(1);

        try
        {
            while (socket.State == WebSocketState.Open)
            {
                var receiveTask = socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                var delayTask = Task.Delay(0);
                var completed = await Task.WhenAny(receiveTask, delayTask);
                if (completed == receiveTask)
                {
                    var result = receiveTask.Result;
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await socket.CloseAsync(WebSocketCloseStatus.NormalClosure,
                                               "Client closed",
                                               CancellationToken.None);
                        break;
                    }
                }

                foreach (var sym in latest.Keys)
                {
                    try
                    {
                        var doc = JsonDocument.Parse(latest[sym]);
                        var root = doc.RootElement;
                        var price = decimal.Parse(root.GetProperty("c").GetString()!);
                        var ts = root.GetProperty("E").GetInt64();

                        var dataObj = new
                        {
                            type = "update",
                            data = new[]
                            {
                            new {
                                symbol = sym.ToUpper(),
                                price,
                                timestamp = ts
                            }
                        }
                        };

                        var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(dataObj));
                        await socket.SendAsync(bytes, WebSocketMessageType.Text, true, CancellationToken.None);
                    }
                    catch { }
                }

                await Task.Delay(sendInterval);
            }
        }
        catch (WebSocketException) { }
        catch (OperationCanceledException) { }
        finally
        {
            cts.Cancel();

            if (socket.State != WebSocketState.Closed)
            {
                try
                {
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure,
                                            "Cleaning up",
                                            CancellationToken.None);
                }
                catch { }
            }
        }
    }
}