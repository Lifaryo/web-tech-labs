﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

[ApiController]
public class WebSocketController : ControllerBase
{
    private readonly OAuthOptions _oauthOptions;
    private readonly CryptoWebSocketHandler _handler;

    public WebSocketController(CryptoWebSocketHandler handler, IOptions<OAuthOptions> options)
    {
        _handler = handler;
        _oauthOptions = options.Value;
    }

    [Route("/api/ws/crypto")]
    public async Task Get()
    {
        if (!HttpContext.WebSockets.IsWebSocketRequest)
        {
            HttpContext.Response.StatusCode = 400;
            return;
        }

        if (!Request.Cookies.TryGetValue("access_token", out var accessToken) || string.IsNullOrEmpty(accessToken))
        {
            HttpContext.Response.StatusCode = 401;
            return;
        }

        try
        {
            var payloadJson = JwtDecoder.DecodeJwtPayload(accessToken);

            using var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(_oauthOptions.JwtVerifyEndpoint);
            var jwks = await response.Content.ReadAsStringAsync();

            if (!JwtDecoder.ValidateJwt(accessToken, jwks))
            {
                Console.WriteLine("Invalid or expired access token according to Casdoor");
                HttpContext.Response.StatusCode = 401;
                return;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error decoding JWT or validating token: " + ex.Message);
            HttpContext.Response.StatusCode = 401;
            return;
        }

        using var ws = await HttpContext.WebSockets.AcceptWebSocketAsync();
        await _handler.HandleSocketAsync(ws);
    }
}
