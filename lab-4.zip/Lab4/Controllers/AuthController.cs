﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;
using System.Text.Json;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly OAuthOptions _oauthOptions;

    public AuthController(IOptions<OAuthOptions> options)
    {
        _oauthOptions = options.Value;
    }

    [HttpGet("login")]
    public IActionResult Login([FromQuery] string returnUrl = "/")
    {
        var redirectUri = Url.Action(nameof(Callback), "Auth", null, Request.Scheme)!;

        var authorizeUrl = QueryHelpers.AddQueryString(
            _oauthOptions.AuthorizeEndpoint,
            new Dictionary<string, string?>
            {
                ["client_id"] = _oauthOptions.ClientId,
                ["redirect_uri"] = redirectUri,
                ["response_type"] = "code",
                ["scope"] = _oauthOptions.Scope,
                ["state"] = returnUrl
            });

        return Redirect(authorizeUrl);
    }

    [HttpGet("callback")]
    public async Task<IActionResult> Callback([FromQuery] string code, [FromQuery] string? state)
    {
        var redirectUri = Url.Action(nameof(Callback), "Auth", null, Request.Scheme)!;

        using var http = new HttpClient();
        var tokenRequest = new HttpRequestMessage(HttpMethod.Post, _oauthOptions.TokenEndpoint)
        {
            Content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "authorization_code",
                ["code"] = code,
                ["redirect_uri"] = redirectUri,
                ["client_id"] = _oauthOptions.ClientId,
                ["client_secret"] = _oauthOptions.ClientSecret
            })
        };

        var tokenResponse = await http.SendAsync(tokenRequest);
        tokenResponse.EnsureSuccessStatusCode();

        var payload = await tokenResponse.Content.ReadAsStringAsync();

        using var doc = JsonDocument.Parse(payload);
        if (!doc.RootElement.TryGetProperty("access_token", out var accessTokenElement))
            return BadRequest("No access_token found in the token response.");

        string accessToken = accessTokenElement.GetString() ?? string.Empty;

        var cookieOptions = new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Lax,
            Expires = DateTimeOffset.UtcNow.AddHours(1)
        };

        Response.Cookies.Append("access_token", accessToken, cookieOptions);

        var returnUrl = !string.IsNullOrEmpty(state) ? state! : "/";
        return Redirect(returnUrl);
    }
}
